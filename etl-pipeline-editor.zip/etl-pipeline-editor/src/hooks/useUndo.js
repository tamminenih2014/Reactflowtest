import { useState } from 'react';

export function useUndo(initialState) {
  const [history, setHistory] = useState([initialState]);
  const [index, setIndex] = useState(0);

  const set = (newState) => {
    const updated = [...history.slice(0, index + 1), newState];
    setHistory(updated);
    setIndex(updated.length - 1);
  };

  const undo = () => {
    if (index > 0) setIndex(index - 1);
  };

  const redo = () => {
    if (index < history.length - 1) setIndex(index + 1);
  };

  return {
    state: history[index],
    set,
    undo,
    redo,
    canUndo: index > 0,
    canRedo: index < history.length - 1
  };
}