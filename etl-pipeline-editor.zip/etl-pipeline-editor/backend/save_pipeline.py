from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import json
import os

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Pipeline(BaseModel):
    nodes: list
    edges: list
    metadata: dict = {}

@app.post("/api/save-pipeline")
async def save_pipeline(pipeline: Pipeline):
    os.makedirs("saved_pipelines", exist_ok=True)
    file_path = f"saved_pipelines/{pipeline.metadata.get('name', 'untitled')}.json"
    with open(file_path, "w") as f:
        json.dump(pipeline.dict(), f, indent=2)
    return {"message": f"Saved pipeline to {file_path}"}